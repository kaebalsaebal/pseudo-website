import { initializeApp } from 'firebase/app';

self.addEventListener('install', () => {
	console.log('연결되었어요');
});
