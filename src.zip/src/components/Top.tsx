const Top = () => {
	return (
		<div>
			<h1>Tosso test</h1>
		</div>
	);
};

export default Top;
