const Footer = () => {
	return <div>Tosso test Inc.</div>;
};

export default Footer;
