function Dachs() {
	return <p>메인화면으로 이동...</p>;
}

export default Dachs;
