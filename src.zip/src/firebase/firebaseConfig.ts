// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
	apiKey: 'AIzaSyDLxBTYDYOltj-0C4X9KvZrvEbuuCnO14Y',
	authDomain: 'kmumpj.firebaseapp.com',
	databaseURL: 'https://kmumpj.firebaseio.com',
	projectId: 'kmumpj',
	storageBucket: 'kmumpj.appspot.com',
	messagingSenderId: '448588964761',
	appId: '1:448588964761:web:2bd80db455ed0aebb6a908',
	measurementId: 'G-6DC3FVQBGH',
};

export const serkey =
	'AAAAaHH8Y5k:APA91bFroyszA1wYWGFenQ-nDHMSWtZ0uuDrHilVnskj9qb4XSTYGUYEMcfqo2BEJbDyUaCWlqhIqfYAJg6gWz_5tExtlPP7eyToi76vzg9wPOnfvjHzNFbWU8nnm16hJi46RGCI4_jG';
export const clikey =
	'BE0mxHsvkZjxVY3tiAsWIntMdNX4LkOo6BjdRX_Kr0G4D9tn5kkfGtWpeBKht9ky0fecsQigODxVuV9bqTza4Mw';

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const database = getFirestore(app);
